Replace this file with your real `google-services.json`.

Get it from: Firebase console -> your project -> Project settings ->
scroll to "Your apps" -> Android app (register one if you haven't, using
applicationId `com.indoortracker.app` to match build.gradle) -> download
`google-services.json` -> put it directly in `android-app/app/` (same folder
as this file) -> delete this placeholder.

If you don't want Firestore sync at all (the app works fine locally without
it), remove the `id 'com.google.gms.google-services'` line from
`app/build.gradle` and the Firebase dependency block, instead of adding a
real config file.
