package com.indoortracker.app.ui.home

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.indoortracker.app.R
import com.indoortracker.app.WifiScanService
import com.indoortracker.app.databinding.FragmentHomeBinding

/**
 * Landing screen: handles permission requests, shows this device's ID
 * (needed if using the optional web dashboard), starts the scanning
 * service, and navigates to the map screen.
 */
class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private val requiredPermissions: Array<String>
        get() = if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES, Manifest.permission.POST_NOTIFICATIONS)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            startScanning()
        } else {
            Toast.makeText(
                requireContext(),
                "WiFi scanning needs these permissions to work — this is an Android OS requirement to release scan results, not extra data this app is choosing to collect.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.deviceIdText.text = "Device ID: ${WifiScanService.getDeviceId(requireContext())}\n(only needed if you're using the optional web dashboard)"

        binding.startScanningButton.setOnClickListener {
            ensurePermissions { startScanning() }
        }

        binding.openMapButton.setOnClickListener {
            ensurePermissions {
                startScanning()
                findNavController().navigate(R.id.action_home_to_map)
            }
        }
    }

    private fun ensurePermissions(action: () -> Unit) {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(requireContext(), it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) action() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun startScanning() {
        val intent = Intent(requireContext(), WifiScanService::class.java).apply {
            putExtra(WifiScanService.EXTRA_SYNC_FIRESTORE, binding.syncFirestoreSwitch.isChecked)
        }
        ContextCompat.startForegroundService(requireContext(), intent)
        Toast.makeText(requireContext(), "Scanning started — updates roughly every 20-30s (Android limits scan frequency)", Toast.LENGTH_LONG).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
