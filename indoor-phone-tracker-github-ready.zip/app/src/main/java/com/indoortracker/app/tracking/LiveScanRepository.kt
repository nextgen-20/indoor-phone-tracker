package com.indoortracker.app.tracking

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * In-process holder for the most recent WiFi scan, shared between
 * WifiScanService (the writer) and MapFragment/MapViewModel (the reader).
 *
 * This works because the service and the UI run in the same app process —
 * no IPC, no broadcast, no Room round-trip needed just to show a live dot.
 * Room is still used to persist saved fingerprints and house maps.
 */
object LiveScanRepository {
    data class ScanSnapshot(
        val signals: Map<String, Int>,
        val timestamp: Long
    )

    private val _latest = MutableStateFlow<ScanSnapshot?>(null)
    val latest: StateFlow<ScanSnapshot?> = _latest

    fun update(signals: Map<String, Int>) {
        _latest.value = ScanSnapshot(signals, System.currentTimeMillis())
    }
}
