package com.indoortracker.app.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface FingerprintDao {
    @Insert
    suspend fun insert(fingerprint: FingerprintEntity): Long

    @Query("SELECT * FROM fingerprints WHERE mapName = :mapName")
    suspend fun getForMap(mapName: String): List<FingerprintEntity>

    @Query("DELETE FROM fingerprints WHERE mapName = :mapName")
    suspend fun clearForMap(mapName: String)
}
