package com.indoortracker.app.tracking

import com.indoortracker.app.db.FingerprintEntity
import com.indoortracker.app.db.SignalMapConverters
import kotlin.math.sqrt
import kotlin.math.min

data class PositionEstimate(val x: Double, val y: Double, val confidenceRadiusNorm: Double)

/**
 * k-NN fingerprint matching: compares a live signal vector against all saved
 * fingerprints for the current map, finds the closest matches by Euclidean
 * distance in signal space, and returns a distance-weighted position estimate.
 *
 * This is the same approach used by professional indoor-positioning tools —
 * it tolerates multipath/attenuation far better than raw RSSI-to-distance
 * trilateration, at the cost of needing a one-time calibration walk.
 */
object PositionEstimator {

    private const val MISSING_RSSI_FLOOR = -100 // penalty for a BSSID not seen at all
    private const val K = 3

    fun estimate(liveSignals: Map<String, Int>, fingerprints: List<FingerprintEntity>): PositionEstimate? {
        if (fingerprints.isEmpty() || liveSignals.isEmpty()) return null

        val scored = fingerprints.map { fp ->
            val fpSignals = SignalMapConverters.decode(fp.signalsJson)
            fp to signalDistance(liveSignals, fpSignals)
        }.sortedBy { it.second }

        val top = scored.take(min(K, scored.size))
        var sumWeight = 0.0
        var sumX = 0.0
        var sumY = 0.0
        top.forEach { (fp, dist) ->
            val weight = 1.0 / (dist + 1.0) // +1 avoids divide-by-zero on an exact match
            sumWeight += weight
            sumX += weight * fp.x
            sumY += weight * fp.y
        }
        val avgDist = top.sumOf { it.second } / top.size

        // Heuristic confidence radius — a practical match-quality indicator,
        // not a statistically rigorous confidence interval.
        val radiusNorm = min(0.35, 0.03 + avgDist * 0.01)

        return PositionEstimate(sumX / sumWeight, sumY / sumWeight, radiusNorm)
    }

    private fun signalDistance(a: Map<String, Int>, b: Map<String, Int>): Double {
        val keys = a.keys + b.keys
        var sumSq = 0.0
        keys.forEach { k ->
            val va = a[k] ?: MISSING_RSSI_FLOOR
            val vb = b[k] ?: MISSING_RSSI_FLOOR
            sumSq += (va - vb).toDouble() * (va - vb).toDouble()
        }
        return sqrt(sumSq / keys.size.coerceAtLeast(1))
    }
}

/**
 * Simple scalar Kalman filter, applied independently to the x and y axes,
 * to smooth the position estimate over successive scans so the dot doesn't
 * jump erratically between individual noisy readings.
 */
class KalmanAxis(private val processNoise: Double = 0.001, private val measurementNoise: Double = 0.05) {
    private var estimate: Double? = null
    private var errorCovariance: Double = 1.0

    fun update(measurement: Double): Double {
        val current = estimate
        if (current == null) {
            estimate = measurement
            return measurement
        }
        errorCovariance += processNoise
        val kalmanGain = errorCovariance / (errorCovariance + measurementNoise)
        val updated = current + kalmanGain * (measurement - current)
        errorCovariance = (1 - kalmanGain) * errorCovariance
        estimate = updated
        return updated
    }

    fun reset() {
        estimate = null
        errorCovariance = 1.0
    }
}
