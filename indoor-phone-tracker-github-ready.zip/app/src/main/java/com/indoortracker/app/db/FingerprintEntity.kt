package com.indoortracker.app.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One recorded WiFi "fingerprint": the full signal vector (BSSID -> RSSI)
 * observed at a known (x, y) spot on a specific house map, plus a human label.
 *
 * x and y are normalized 0.0-1.0 (fraction of the floor plan image width/height),
 * so they stay valid even if the map image is displayed at different sizes.
 */
@Entity(tableName = "fingerprints")
data class FingerprintEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mapName: String,
    val label: String,
    val x: Double,
    val y: Double,
    val signalsJson: String, // Map<String, Int> (BSSID -> RSSI dBm), JSON-encoded
    val timestamp: Long = System.currentTimeMillis()
)
