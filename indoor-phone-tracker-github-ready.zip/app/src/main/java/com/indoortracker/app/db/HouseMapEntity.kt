package com.indoortracker.app.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A saved floor plan. The image is stored as a file path (in app-private
 * storage) rather than raw bytes in the DB, to keep Room rows small.
 */
@Entity(tableName = "house_maps")
data class HouseMapEntity(
    @PrimaryKey val name: String,
    val imagePath: String,
    val createdAt: Long = System.currentTimeMillis()
)
