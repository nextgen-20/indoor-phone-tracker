package com.indoortracker.app.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface HouseMapDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(map: HouseMapEntity)

    @Query("SELECT * FROM house_maps WHERE name = :name LIMIT 1")
    suspend fun getByName(name: String): HouseMapEntity?
}
