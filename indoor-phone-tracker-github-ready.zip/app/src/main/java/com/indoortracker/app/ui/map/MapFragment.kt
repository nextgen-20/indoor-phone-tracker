package com.indoortracker.app.ui.map

import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.indoortracker.app.databinding.FragmentMapBinding
import kotlinx.coroutines.launch

/**
 * Main working screen. Two modes:
 *  - Calibrate: tap a spot on the floor plan, save the phone's current live
 *    scan as a labeled fingerprint at that spot.
 *  - Track: continuously match live scans against saved fingerprints
 *    (k-NN) and show a smoothed (Kalman-filtered) position dot with a
 *    confidence circle.
 */
class MapFragment : Fragment() {

    private var _binding: FragmentMapBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MapViewModel by viewModels()

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.importFloorPlan(it) }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentMapBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.floorPlanView.onTap = { nx, ny -> onMapTapped(nx, ny) }

        binding.uploadPlanButton.setOnClickListener { pickImageLauncher.launch("image/*") }

        binding.mapNameInput.setText(viewModel.currentMapName)
        binding.saveMapButton.setOnClickListener {
            val name = binding.mapNameInput.text.toString().trim()
            if (name.isEmpty()) { toast("Enter a map name first."); return@setOnClickListener }
            viewModel.saveCurrentMap(name)
            toast("Saved map \"$name\"")
        }
        binding.loadMapButton.setOnClickListener {
            val name = binding.mapNameInput.text.toString().trim()
            if (name.isEmpty()) { toast("Enter the map name to load."); return@setOnClickListener }
            viewModel.loadMap(name)
        }

        binding.modeCalibrateButton.setOnClickListener { setMode(MapViewModel.Mode.CALIBRATE) }
        binding.modeTrackButton.setOnClickListener { setMode(MapViewModel.Mode.TRACK) }
        setMode(MapViewModel.Mode.CALIBRATE)

        binding.clearFingerprintsButton.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Clear all fingerprints?")
                .setMessage("This removes every recorded fingerprint for this map. Cannot be undone.")
                .setPositiveButton("Clear") { _, _ -> viewModel.clearFingerprints() }
                .setNegativeButton("Cancel", null)
                .show()
        }

        observeState()
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.floorPlanBitmap.collect { bmp -> binding.floorPlanView.floorPlan = bmp }
                }
                launch {
                    viewModel.fingerprints.collect { list ->
                        binding.floorPlanView.fingerprints = list
                        binding.fingerprintCountText.text = "${list.size} fingerprint${if (list.size == 1) "" else "s"} recorded"
                    }
                }
                launch {
                    viewModel.liveDot.collect { dot -> binding.floorPlanView.liveEstimate = dot }
                }
                launch {
                    viewModel.statusMessage.collect { msg -> if (msg != null) binding.statusText.text = msg }
                }
            }
        }
    }

    private fun setMode(mode: MapViewModel.Mode) {
        viewModel.setMode(mode)
        binding.modeCalibrateButton.isSelected = mode == MapViewModel.Mode.CALIBRATE
        binding.modeTrackButton.isSelected = mode == MapViewModel.Mode.TRACK
        binding.statusText.text = when (mode) {
            MapViewModel.Mode.CALIBRATE -> "Tap a spot on the map to save your phone's current reading as a fingerprint there."
            MapViewModel.Mode.TRACK -> "Live tracking — the dot follows your estimated position (updates every ~4s from the last scan)."
        }
    }

    private fun onMapTapped(nx: Float, ny: Float) {
        if (viewModel.mode.value != MapViewModel.Mode.CALIBRATE) return

        val input = EditText(requireContext()).apply { hint = "Label (e.g. Kitchen corner)" }
        AlertDialog.Builder(requireContext())
            .setTitle("Record fingerprint here")
            .setMessage("Uses the phone's most recent WiFi scan. Make sure you're actually standing at this spot.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val label = input.text.toString().trim().ifEmpty { "Point" }
                val saved = viewModel.recordFingerprint(nx, ny, label)
                if (!saved) toast("No recent WiFi scan available yet — wait a few seconds after starting scanning and try again.")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toast(msg: String) = Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
