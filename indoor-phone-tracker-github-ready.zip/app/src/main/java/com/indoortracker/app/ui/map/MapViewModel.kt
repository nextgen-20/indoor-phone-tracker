package com.indoortracker.app.ui.map

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.indoortracker.app.db.AppDatabase
import com.indoortracker.app.db.FingerprintEntity
import com.indoortracker.app.db.HouseMapEntity
import com.indoortracker.app.db.SignalMapConverters
import com.indoortracker.app.tracking.KalmanAxis
import com.indoortracker.app.tracking.LiveScanRepository
import com.indoortracker.app.tracking.PositionEstimator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * AndroidViewModel (not a plain ViewModel + static context) so it can hold
 * an application Context safely for Room/file access without leaking an
 * Activity or Fragment reference.
 */
class MapViewModel(application: Application) : AndroidViewModel(application) {

    enum class Mode { CALIBRATE, TRACK }

    var currentMapName: String = "default"
        private set

    private val db by lazy { AppDatabase.getInstance(getApplication<Application>()) }

    private val _floorPlanBitmap = MutableStateFlow<Bitmap?>(null)
    val floorPlanBitmap: StateFlow<Bitmap?> = _floorPlanBitmap.asStateFlow()

    private val _fingerprints = MutableStateFlow<List<FingerprintEntity>>(emptyList())
    val fingerprints: StateFlow<List<FingerprintEntity>> = _fingerprints.asStateFlow()

    private val _liveDot = MutableStateFlow<FloorPlanView.LiveDot?>(null)
    val liveDot: StateFlow<FloorPlanView.LiveDot?> = _liveDot.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _mode = MutableStateFlow(Mode.CALIBRATE)
    val mode: StateFlow<Mode> = _mode.asStateFlow()

    private val kalmanX = KalmanAxis()
    private val kalmanY = KalmanAxis()
    private var trackingJob: Job? = null

    init {
        // Load any previously recorded fingerprints for the default map on start
        viewModelScope.launch(Dispatchers.IO) { reloadFingerprints() }
    }

    fun setMode(newMode: Mode) {
        _mode.value = newMode
        trackingJob?.cancel()
        if (newMode == Mode.TRACK) {
            kalmanX.reset(); kalmanY.reset()
            startTrackingLoop()
        } else {
            _liveDot.value = null
        }
    }

    private fun startTrackingLoop() {
        trackingJob = viewModelScope.launch {
            while (true) {
                val snapshot = LiveScanRepository.latest.value
                val fps = _fingerprints.value
                if (fps.isEmpty()) {
                    _statusMessage.value = "Record at least a few fingerprints in Calibrate mode first."
                } else if (snapshot != null) {
                    val estimate = PositionEstimator.estimate(snapshot.signals, fps)
                    if (estimate != null) {
                        val sx = kalmanX.update(estimate.x)
                        val sy = kalmanY.update(estimate.y)
                        _liveDot.value = FloorPlanView.LiveDot(
                            sx.toFloat(), sy.toFloat(), estimate.confidenceRadiusNorm.toFloat()
                        )
                    }
                }
                delay(4000)
            }
        }
    }

    /** Returns false if there's no recent scan available to record yet. */
    fun recordFingerprint(nx: Float, ny: Float, label: String): Boolean {
        val snapshot = LiveScanRepository.latest.value ?: return false
        viewModelScope.launch(Dispatchers.IO) {
            db.fingerprintDao().insert(
                FingerprintEntity(
                    mapName = currentMapName,
                    label = label,
                    x = nx.toDouble(),
                    y = ny.toDouble(),
                    signalsJson = SignalMapConverters.encode(snapshot.signals)
                )
            )
            reloadFingerprints()
        }
        return true
    }

    fun clearFingerprints() {
        viewModelScope.launch(Dispatchers.IO) {
            db.fingerprintDao().clearForMap(currentMapName)
            reloadFingerprints()
        }
    }

    private suspend fun reloadFingerprints() {
        val list = db.fingerprintDao().getForMap(currentMapName)
        _fingerprints.value = list
    }

    fun importFloorPlan(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
                val bmp = BitmapFactory.decodeStream(input)
                withContext(Dispatchers.Main) { _floorPlanBitmap.value = bmp }
            }
        }
    }

    fun saveCurrentMap(name: String) {
        val bmp = _floorPlanBitmap.value ?: run {
            _statusMessage.value = "Upload a floor plan image first."
            return
        }
        currentMapName = name
        viewModelScope.launch(Dispatchers.IO) {
            val dir = File(getApplication<Application>().filesDir, "maps").apply { mkdirs() }
            val file = File(dir, "$name.png")
            FileOutputStream(file).use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }
            db.houseMapDao().upsert(HouseMapEntity(name = name, imagePath = file.absolutePath))
            reloadFingerprints()
        }
    }

    fun loadMap(name: String) {
        currentMapName = name
        viewModelScope.launch(Dispatchers.IO) {
            val entity = db.houseMapDao().getByName(name)
            if (entity == null) {
                _statusMessage.value = "No saved map named \"$name\"."
                return@launch
            }
            val bmp = BitmapFactory.decodeFile(entity.imagePath)
            withContext(Dispatchers.Main) { _floorPlanBitmap.value = bmp }
            reloadFingerprints()
        }
    }
}
