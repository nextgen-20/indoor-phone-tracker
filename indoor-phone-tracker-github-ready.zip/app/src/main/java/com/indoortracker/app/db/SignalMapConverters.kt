package com.indoortracker.app.db

import org.json.JSONObject

/**
 * Manual JSON encode/decode for the BSSID->RSSI signal map, avoiding a
 * dependency on kotlinx.serialization or Gson just for this one small type.
 */
object SignalMapConverters {

    fun encode(signals: Map<String, Int>): String {
        val json = JSONObject()
        signals.forEach { (bssid, rssi) -> json.put(bssid, rssi) }
        return json.toString()
    }

    fun decode(json: String): Map<String, Int> {
        if (json.isBlank()) return emptyMap()
        val obj = JSONObject(json)
        val map = mutableMapOf<String, Int>()
        obj.keys().forEach { key -> map[key] = obj.getInt(key) }
        return map
    }
}
