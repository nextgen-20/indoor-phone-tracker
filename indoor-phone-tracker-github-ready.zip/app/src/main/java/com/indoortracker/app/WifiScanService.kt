package com.indoortracker.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.firebase.firestore.FirebaseFirestore
import com.indoortracker.app.tracking.LiveScanRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Foreground service that scans WiFi periodically.
 *
 * Data flow:
 *  1. Every scan result is pushed into LiveScanRepository (in-process, instant) —
 *     this is what MapFragment reads for the live tracking dot.
 *  2. The same reading is optionally mirrored to Firestore's `liveReadings`
 *     collection, purely so the web dashboard (a secondary viewer) can see it
 *     too. The app's own live tracking does NOT depend on Firestore at all —
 *     it works fully offline once fingerprints are recorded locally.
 *
 * REAL-WORLD CONSTRAINT: Android throttles WifiManager.startScan() to roughly
 * 4 calls per 2-minute window per app (since Android 9 / API 28). This service
 * requests a scan every SCAN_INTERVAL_MS, but the OS may silently ignore
 * requests beyond that throttle and just keep returning the last cached scan
 * results. In practice, expect updates roughly every 20-30 seconds, not
 * multiple times per second. This is a platform limit, not fixable from app code.
 */
class WifiScanService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private lateinit var wifiManager: WifiManager

    // Firebase is optional (see app/build.gradle — the google-services plugin
    // only applies if a real google-services.json is present). If it wasn't
    // configured, FirebaseFirestore.getInstance() throws; catching that here
    // means the app runs fine in local-only mode instead of crashing.
    private val firestore: FirebaseFirestore? by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: IllegalStateException) {
            null
        }
    }

    private val deviceId: String by lazy {
        val prefs = getSharedPreferences("tracker_prefs", MODE_PRIVATE)
        prefs.getString("device_id", null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString("device_id", it).apply()
        }
    }

    private var syncToFirestore: Boolean = true

    private val scanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val success = intent.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false)
            handleScanResults(freshScan = success)
        }
    }

    override fun onCreate() {
        super.onCreate()
        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        registerReceiver(scanReceiver, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION))
        val statusText = if (firestore != null) "Scanning WiFi signal..." else "Scanning WiFi signal (local only — Firebase not configured)"
        startForeground(NOTIFICATION_ID, buildNotification(statusText))
        startScanLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            syncToFirestore = it.getBooleanExtra(EXTRA_SYNC_FIRESTORE, true)
        }
        return START_STICKY
    }

    private fun startScanLoop() {
        scope.launch {
            while (true) {
                @Suppress("DEPRECATION")
                wifiManager.startScan() // Android may throttle this; see class doc
                delay(SCAN_INTERVAL_MS)
            }
        }
    }

    private fun handleScanResults(freshScan: Boolean) {
        @Suppress("DEPRECATION")
        val results = wifiManager.scanResults ?: return
        if (results.isEmpty()) return

        val signalMap = results.associate { it.BSSID to it.level }

        // 1. Always update the in-process repository — this is what drives
        //    the live tracking dot on the map screen, no network needed.
        LiveScanRepository.update(signalMap)

        // 2. Optionally mirror to Firestore for the web dashboard / backup.
        //    No-ops silently if Firebase isn't configured (firestore == null)
        //    or the user hasn't enabled sync.
        if (syncToFirestore && firestore != null) {
            val reading = hashMapOf(
                "deviceId" to deviceId,
                "signals" to signalMap,
                "timestamp" to System.currentTimeMillis(),
                "freshScan" to freshScan
            )
            firestore!!.collection("liveReadings").document(deviceId).set(reading)
        }
    }

    private fun buildNotification(text: String): Notification {
        val channelId = "wifi_scan_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "WiFi Scanning", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Indoor Phone Tracker")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(scanReceiver)
        scope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val SCAN_INTERVAL_MS = 20_000L
        const val NOTIFICATION_ID = 1001
        const val EXTRA_SYNC_FIRESTORE = "sync_firestore"

        fun getDeviceId(context: Context): String {
            val prefs = context.getSharedPreferences("tracker_prefs", Context.MODE_PRIVATE)
            return prefs.getString("device_id", null) ?: run {
                val id = UUID.randomUUID().toString()
                prefs.edit().putString("device_id", id).apply()
                id
            }
        }
    }
}
