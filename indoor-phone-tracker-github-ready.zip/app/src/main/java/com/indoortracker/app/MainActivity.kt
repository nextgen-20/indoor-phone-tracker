package com.indoortracker.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import com.indoortracker.app.databinding.ActivityMainBinding

/**
 * Hosts the navigation graph (Home -> Map). All real logic lives in the
 * fragments; this activity just wires up the NavHostFragment.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // NavHostFragment is declared in activity_main.xml and drives itself
        // via nav_graph.xml — nothing else to wire here.
    }
}
