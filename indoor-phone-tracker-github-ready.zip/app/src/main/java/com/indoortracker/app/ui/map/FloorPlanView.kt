package com.indoortracker.app.ui.map

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.indoortracker.app.db.FingerprintEntity

/**
 * Custom drawing surface for the floor plan screen. Draws the uploaded floor
 * plan bitmap, all recorded fingerprint markers, and (in track mode) the
 * live estimated position with its confidence circle.
 *
 * Tap coordinates are reported back as normalized 0.0-1.0 fractions of the
 * bitmap's width/height, independent of how the view is scaled on screen.
 */
class FloorPlanView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var floorPlan: Bitmap? = null
        set(value) { field = value; invalidate() }

    var fingerprints: List<FingerprintEntity> = emptyList()
        set(value) { field = value; invalidate() }

    var liveEstimate: LiveDot? = null
        set(value) { field = value; invalidate() }

    var onTap: ((normX: Float, normY: Float) -> Unit)? = null

    data class LiveDot(val x: Float, val y: Float, val confidenceRadiusNorm: Float)

    private val fpPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4FD1C5") }
    private val fpStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0A0E13"); style = Paint.Style.STROKE; strokeWidth = 4f
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFD93D") }
    private val circleFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#33FFD93D")
    }
    private val circleStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#80FFD93D"); style = Paint.Style.STROKE; strokeWidth = 2f
    }
    private val bgPaint = Paint().apply { color = Color.parseColor("#0D1319") }

    // Cached scale/offset of the bitmap within the view (letterboxed, aspect-fit)
    private var drawLeft = 0f
    private var drawTop = 0f
    private var drawScale = 1f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        val bmp = floorPlan ?: return
        computeFit(bmp)
        val destW = bmp.width * drawScale
        val destH = bmp.height * drawScale
        canvas.drawBitmap(bmp, null, android.graphics.RectF(drawLeft, drawTop, drawLeft + destW, drawTop + destH), null)

        fingerprints.forEach { fp ->
            val px = drawLeft + fp.x.toFloat() * destW
            val py = drawTop + fp.y.toFloat() * destH
            canvas.drawCircle(px, py, 14f, fpPaint)
            canvas.drawCircle(px, py, 14f, fpStroke)
        }

        liveEstimate?.let { dot ->
            val px = drawLeft + dot.x * destW
            val py = drawTop + dot.y * destH
            val radiusPx = dot.confidenceRadiusNorm * maxOf(destW, destH)
            canvas.drawCircle(px, py, radiusPx, circleFillPaint)
            canvas.drawCircle(px, py, radiusPx, circleStrokePaint)
            canvas.drawCircle(px, py, 18f, dotPaint)
            canvas.drawCircle(px, py, 18f, fpStroke)
        }
    }

    private fun computeFit(bmp: Bitmap) {
        val scaleX = width.toFloat() / bmp.width
        val scaleY = height.toFloat() / bmp.height
        drawScale = minOf(scaleX, scaleY)
        drawLeft = (width - bmp.width * drawScale) / 2f
        drawTop = (height - bmp.height * drawScale) / 2f
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val bmp = floorPlan ?: return true
        computeFit(bmp)
        val destW = bmp.width * drawScale
        val destH = bmp.height * drawScale
        val nx = (event.x - drawLeft) / destW
        val ny = (event.y - drawTop) / destH
        if (nx in 0f..1f && ny in 0f..1f) {
            onTap?.invoke(nx, ny)
        }
        return true
    }
}
